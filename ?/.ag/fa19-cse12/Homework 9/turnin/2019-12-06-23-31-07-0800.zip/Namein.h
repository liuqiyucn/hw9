#ifndef NAMEIN_H
#define NAMEIN_H

/* DO NOT CHANGE:  This file is used in evaluation
 * Changing function signatures will result in a 25% deduction.
 * */

char * namein (char *);

#endif
